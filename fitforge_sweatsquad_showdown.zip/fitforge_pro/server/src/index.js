import express from 'express';
import cors from 'cors';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';

const app = express();
const PORT = process.env.PORT || 4000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.join(__dirname, '../data/db.json');
app.use(cors());
app.use(express.json());

const readDB = () => JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
const writeDB = (db) => fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
const MET = { Running: 8.3, Cycling: 7.5, 'Push-ups': 6.0, Gym: 5.0 };
const INTENSITY = { low: 0.8, moderate: 1.0, high: 1.2 };

function calculatePoints(type, duration, intensity) {
  const raw = duration * (MET[type] || 5) * (INTENSITY[intensity] || 1);
  return Math.round(raw);
}
function totals(db) {
  return db.squads.map(s => ({
    ...s,
    points: db.workouts.filter(w => w.squadId === s.id).reduce((n,w) => n + w.points, 0),
    members: s.memberIds.map(id => {
      const user = db.users.find(u => u.id === id);
      return user ? { ...user, points: db.workouts.filter(w => w.userId === id).reduce((n,w) => n + w.points, 0) } : null;
    }).filter(Boolean)
  })).sort((a,b) => b.points - a.points);
}

app.get('/api/health', (_req,res) => res.json({ok:true}));
app.get('/api/dashboard', (_req,res) => {
  const db = readDB();
  const squads = totals(db);
  const activeSquad = squads.find(s => s.id === 's1');
  const recent = db.workouts.slice().sort((a,b) => b.createdAt.localeCompare(a.createdAt)).slice(0,8)
    .map(w => ({...w, user: db.users.find(u => u.id === w.userId)?.name || 'Member'}));
  const daily = Array.from({length:7}, (_,i) => {
    const d = new Date(); d.setDate(d.getDate() - (6-i));
    const key = d.toISOString().slice(0,10);
    return { day: d.toLocaleDateString('en',{weekday:'short'}), points: db.workouts.filter(w => w.squadId === 's1' && w.date === key).reduce((n,w)=>n+w.points,0) };
  });
  res.json({squads, activeSquad, users:db.users, workouts:db.workouts, recent, daily, badges:db.badges});
});
app.post('/api/workouts', (req,res) => {
  const { userId='u1', type, duration, distance=0, intensity='moderate' } = req.body || {};
  const db = readDB();
  const user = db.users.find(u => u.id === userId);
  if (!user) return res.status(404).json({error:'Member not found'});
  if (!MET[type]) return res.status(400).json({error:'Choose a supported activity'});
  if (!Number.isFinite(duration) || duration < 1 || duration > 180) return res.status(400).json({error:'Duration must be between 1 and 180 minutes'});
  if (!Number.isFinite(distance) || distance < 0 || distance > 100) return res.status(400).json({error:'Enter a valid distance'});
  if (!INTENSITY[intensity]) return res.status(400).json({error:'Choose an intensity'});
  const today = new Date().toISOString().slice(0,10);
  const dayTotal = db.workouts.filter(w => w.userId === userId && w.date === today).reduce((n,w)=>n+w.duration,0);
  if (dayTotal + duration > 180) return res.status(429).json({error:'Daily logging limit reached (180 minutes).'});
  const workout = { id:crypto.randomUUID(), userId, squadId:user.squadId, type, duration, distance, intensity, points:calculatePoints(type,duration,intensity), date:today, createdAt:new Date().toISOString() };
  db.workouts.push(workout);
  writeDB(db);
  res.status(201).json({workout, message:`${workout.points} points added to ${db.squads.find(s=>s.id===user.squadId)?.name || 'your squad'}!`});
});
app.post('/api/reactions', (req,res) => {
  const { workoutId, emoji='🙌', userId='u1' } = req.body || {};
  const db = readDB();
  if (!db.workouts.some(w => w.id === workoutId)) return res.status(404).json({error:'Workout not found'});
  db.reactions.push({id:crypto.randomUUID(),workoutId,userId,emoji,createdAt:new Date().toISOString()});
  writeDB(db);
  res.json({ok:true});
});
app.listen(PORT, () => console.log(`FitForge API running at http://localhost:${PORT}`));
