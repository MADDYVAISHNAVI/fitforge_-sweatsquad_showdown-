# FitForge — SweatSquad Showdown

A full-stack hackathon demo based on the supplied FitForge problem brief.

## Stack
- Frontend: React + TypeScript + Vite + Chart.js + Lucide icons
- Backend: Node.js + Express REST API
- Data: JSON store (`server/data/db.json`) for easy local demo

## Requirements
Node.js 18+ and npm.

## Run locally
From the project root:

```bash
npm install
npm run dev
```

Open:
- Frontend: http://localhost:5173
- API health: http://localhost:4000/api/health

For a production frontend build:
```bash
npm run build
npm start
```

## Implemented from the brief
- Workout logger: Running, Cycling, Push-ups, Gym; duration, distance, intensity
- MET point engine: `duration × MET factor × intensity multiplier`
- Intensity multipliers: low 0.8, moderate 1.0, high 1.2
- Squad dashboard and leaderboard
- Squad goal progress and member point totals
- Badge showcase with milestone evaluation
- Seven-day squad points chart
- Activity feed and high-five reactions
- Server-side input validation and 180-minute daily logging limit
- Five seeded squads and eight badge definitions

## Demo walkthrough
1. Open the dashboard and view the seeded squad rankings.
2. Click **Log workout**.
3. Add a 30-minute high-intensity 5 km run.
4. Save to see points update in your squad total and activity log.
5. Explore Leaderboard, Squad Hub, and Achievements.

## Notes
- Seed data is illustrative. The brief's example of a 30-minute high-intensity 5 km run earning 320 points is seeded as the demo example; the configurable formula uses the MET table in `server/src/index.js`.
- This is a hackathon prototype. JSON storage is suitable for a local demo, not concurrent production use. Authentication, invite codes, push notifications, wearable sync, and a real real-time transport (WebSockets) are not implemented.
- Fitness points are game scores, not medical or performance measurements. Choose activity and intensity honestly and comfortably.
