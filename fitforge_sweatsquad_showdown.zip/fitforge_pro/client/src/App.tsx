import { useEffect, useMemo, useState } from 'react';
import { Activity, ArrowUpRight, Award, Bell, Bike, CalendarDays, Check, ChevronDown, Flame, Footprints, Heart, LayoutDashboard, Medal, Plus, ShieldCheck, Sparkles, Target, Users, Zap } from 'lucide-react';
import { Bar, Line } from 'react-chartjs-2';
import { CategoryScale, Chart as ChartJS, Filler, Legend, LinearScale, LineElement, BarElement, PointElement, Tooltip } from 'chart.js';
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, Tooltip, Legend, Filler);

const API = 'http://localhost:4000/api';
type Dashboard = { squads:any[]; activeSquad:any; users:any[]; workouts:any[]; recent:any[]; daily:any[]; badges:any[] };
const money = (n:number) => new Intl.NumberFormat('en-IN').format(n);
const initials = (name:string) => name.split(' ').map(x=>x[0]).slice(0,2).join('');
export default function App() {
  const [data,setData] = useState<Dashboard|null>(null);
  const [page,setPage] = useState('Overview');
  const [modal,setModal] = useState(false);
  const [notice,setNotice] = useState('');
  const [loading,setLoading] = useState(false);
  const [form,setForm] = useState({type:'Running',duration:'30',distance:'5',intensity:'high'});
  const [range,setRange] = useState('Weekly');
  async function refresh() {
    const r = await fetch(`${API}/dashboard`);
    if (!r.ok) throw new Error('Could not load dashboard');
    setData(await r.json());
  }
  useEffect(()=>{ refresh().catch(()=>setNotice('Start the API server to load your dashboard.')); },[]);
  const me = data?.users.find(u=>u.id==='u1');
  const myPoints = data?.workouts.filter(w=>w.userId==='u1').reduce((n,w)=>n+w.points,0) || 0;
  const myWorkouts = data?.workouts.filter(w=>w.userId==='u1') || [];
  const unlocked = useMemo(()=> {
    if(!data) return [];
    const totalDistance = myWorkouts.reduce((n,w)=>n+w.distance,0);
    return data.badges.filter(b =>
      (b.kind==='workouts' && myWorkouts.length>=b.threshold) ||
      (b.kind==='distance' && myWorkouts.some(w=>w.type==='Running' && w.distance>=b.threshold)) ||
      (b.kind==='points' && myPoints>=b.threshold) ||
      (b.kind==='cycle' && myWorkouts.filter(w=>w.type==='Cycling').reduce((n,w)=>n+w.distance,0)>=b.threshold) ||
      (b.kind==='morning' && myWorkouts.some(w=>new Date(w.createdAt).getHours()<9))
    );
  },[data,myWorkouts,myPoints]);
  async function submitWorkout(e:React.FormEvent) {
    e.preventDefault(); setLoading(true); setNotice('');
    try {
      const r=await fetch(`${API}/workouts`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({userId:'u1',type:form.type,duration:Number(form.duration),distance:Number(form.distance),intensity:form.intensity})});
      const result=await r.json(); if(!r.ok) throw new Error(result.error || 'Unable to save workout');
      setNotice(result.message); setModal(false); await refresh();
    } catch(err:any) { setNotice(err.message); }
    finally { setLoading(false); }
  }
  if(!data) return <div className="loading"><div className="brand-mark">F</div><h2>FITFORGE</h2><p>{notice || 'Preparing your squad dashboard…'}</p><small>Run the API and frontend using the README instructions.</small></div>;
  const active=data.activeSquad || data.squads[0];
  const leaderboard=data.squads;
  const rank=leaderboard.findIndex(s=>s.id==='s1')+1;
  const weeklyTotal=active?.points || 0;
  const chartData={labels:data.daily.map(d=>d.day),datasets:[{label:'Squad points',data:data.daily.map(d=>d.points),borderColor:'#c6f36b',backgroundColor:'rgba(198,243,107,.12)',fill:true,tension:.4,pointRadius:4,pointBackgroundColor:'#c6f36b'}]};
  const chartOptions:any={responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{grid:{display:false},ticks:{color:'#87938e'}},y:{grid:{color:'rgba(255,255,255,.07)'},ticks:{color:'#87938e'}}}};
  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark">F</div><div><b>FITFORGE</b><span>SWEATSQUAD SHOWDOWN</span></div></div>
      <div className="side-label">WORKSPACE</div>
      {['Overview','Leaderboard','Activity Log','Squad Hub','Achievements'].map((item,i)=><button className={`nav-item ${page===item?'active':''}`} onClick={()=>setPage(item)} key={item}>{[<LayoutDashboard/>,<Medal/>,<Activity/>,<Users/>,<Award/>][i]}<span>{item}</span>{item==='Leaderboard'&&<i>LIVE</i>}</button>)}
      <div className="sidebar-bottom"><div className="season-card"><div className="season-icon"><Flame size={18}/></div><small>SEASON 04</small><b>Rise Together</b><p>Keep your squad moving. Every point counts.</p><div className="season-progress"><span style={{width:`${Math.min(100,weeklyTotal/active.goal*100)}%`}}/></div><small>{money(weeklyTotal)} / {money(active.goal)} PTS</small></div><div className="profile-mini"><div className="avatar">AM</div><div><b>{me?.name}</b><span>Squad member</span></div><ChevronDown size={16}/></div></div>
    </aside>
    <main className="main">
      <header className="topbar"><div><div className="eyebrow">THURSDAY, NOVEMBER 20, 2026</div><h1>{page==='Overview'?'Your squad. Your momentum.':page}</h1></div><div className="top-actions"><div className="season-pill"><span className="live-dot"/> CHALLENGE LIVE</div><button className="icon-btn" aria-label="Notifications"><Bell size={18}/><i/></button><button className="primary-btn" onClick={()=>setModal(true)}><Plus size={17}/> Log workout</button></div></header>
      {notice && <div className="notice" onClick={()=>setNotice('')}>{notice}<button>×</button></div>}
      {page==='Overview' && <>
        <section className="hero">
          <div className="hero-copy"><div className="hero-tag"><Sparkles size={13}/> THE POWER OF SHOWING UP</div><h2>Small moves.<br/><em>Big momentum.</em></h2><p>Build consistency, back your squad, and turn every workout into progress.</p><button className="hero-btn" onClick={()=>setModal(true)}>Log an activity <ArrowUpRight size={17}/></button></div>
          <div className="hero-art"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="hero-runner"><Footprints size={84}/></div><div className="float-chip chip-one"><Zap size={15}/> +320 PTS</div><div className="float-chip chip-two"><Flame size={15}/> 5 DAY STREAK</div><div className="hero-number">01<span>/05</span></div></div>
        </section>
        <section className="stats-grid">
          <Stat icon={<Zap/>} label="YOUR TOTAL POINTS" value={money(myPoints)} change="Across all logged workouts" accent="lime"/>
          <Stat icon={<Users/>} label="SQUAD RANK" value={`#${rank}`} change={`${active.name} leaderboard`} accent="purple"/>
          <Stat icon={<Target/>} label="WEEKLY SQUAD GOAL" value={`${Math.min(100,Math.round(weeklyTotal/active.goal*100))}%`} change={`${money(active.goal-weeklyTotal>0?active.goal-weeklyTotal:0)} pts to target`} accent="orange"/>
          <Stat icon={<Flame/>} label="WORKOUTS LOGGED" value={String(myWorkouts.length)} change="Your activity history" accent="blue"/>
        </section>
        <section className="content-grid">
          <div className="panel chart-panel"><div className="panel-head"><div><div className="eyebrow">PERFORMANCE OVERVIEW</div><h3>Squad momentum</h3></div><select value={range} onChange={e=>setRange(e.target.value)}><option>Weekly</option><option>Daily</option><option>Monthly</option></select></div><div className="chart-wrap"><Line data={chartData} options={chartOptions}/></div><div className="chart-foot"><span><i className="legend-dot"/> Points earned by {active.name}</span><b>{money(weeklyTotal)} <small>total points</small></b></div></div>
          <div className="panel leaderboard-panel"><div className="panel-head"><div><div className="eyebrow">THE RACE IS ON</div><h3>Squad leaderboard</h3></div><span className="live-label"><span className="live-dot"/> LIVE</span></div>{leaderboard.slice(0,5).map((s,i)=><div className={`leader-row ${s.id==='s1'?'my-squad':''}`} key={s.id}><div className={`rank rank-${i+1}`}>{String(i+1).padStart(2,'0')}</div><div className={`squad-symbol ${s.color}`}>{s.tag.slice(0,1)}</div><div className="leader-name"><b>{s.name}</b><span>{s.members.length} squad members</span></div><strong>{money(s.points)} <small>pts</small></strong></div>)}</div>
        </section>
        <section className="content-grid lower-grid">
          <div className="panel activity-panel"><div className="panel-head"><div><div className="eyebrow">SQUAD ACTIVITY</div><h3>Latest moves</h3></div><button className="text-btn" onClick={()=>setPage('Activity Log')}>View all <ArrowUpRight size={14}/></button></div>{data.recent.map(w=><div className="activity-row" key={w.id}><div className="activity-icon">{w.type==='Running'?<Footprints/>:w.type==='Cycling'?<Bike/>:<Activity/>}</div><div className="activity-info"><b>{w.user}</b><span>{w.type} · {w.duration} min {w.distance?`· ${w.distance} km`:''}</span></div><div className="activity-points">+{w.points}<small>PTS</small></div><button className="cheer" title="Send a high-five" onClick={async()=>{await fetch(`${API}/reactions`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({workoutId:w.id,emoji:'🙌'})});setNotice('High-five sent! Keep the squad spirit going.')}}><span>🙌</span></button></div>)}</div>
          <div className="panel badges-panel"><div className="panel-head"><div><div className="eyebrow">MILESTONES</div><h3>Badge cabinet</h3></div><span className="badge-count">{unlocked.length}/{data.badges.length}</span></div><div className="badge-grid">{data.badges.map(b=><div className={`badge-tile ${unlocked.some(x=>x.id===b.id)?'earned':''}`} key={b.id}><div>{b.icon}</div><b>{b.name}</b><span>{unlocked.some(x=>x.id===b.id)?'UNLOCKED':'LOCKED'}</span></div>)}</div></div>
        </section>
      </>}
      {page==='Leaderboard' && <section className="panel page-panel"><div className="panel-head"><div><div className="eyebrow">COMPETE AS ONE</div><h3>Squad standings</h3></div><span className="live-label"><span className="live-dot"/> LIVE RANKINGS</span></div>{leaderboard.map((s,i)=><div className="leader-row large" key={s.id}><div className={`rank rank-${i+1}`}>{String(i+1).padStart(2,'0')}</div><div className={`squad-symbol ${s.color}`}>{s.tag.slice(0,1)}</div><div className="leader-name"><b>{s.name}</b><span>{s.members.length} members · Weekly target {money(s.goal)} pts</span></div><div className="goal-track"><span style={{width:`${Math.min(100,s.points/s.goal*100)}%`}}/></div><strong>{money(s.points)} <small>pts</small></strong></div>)}</section>}
      {page==='Activity Log' && <section className="panel page-panel"><div className="panel-head"><div><div className="eyebrow">EVERY REP COUNTS</div><h3>Workout history</h3></div><button className="primary-btn" onClick={()=>setModal(true)}><Plus size={16}/> Add workout</button></div><div className="table-head"><span>MEMBER / ACTIVITY</span><span>DURATION</span><span>INTENSITY</span><span>POINTS</span></div>{data.workouts.slice().reverse().map(w=><div className="table-row" key={w.id}><span><b>{data.users.find(u=>u.id===w.userId)?.name}</b><small>{w.type}{w.distance?` · ${w.distance} km`:''}</small></span><span>{w.duration} min</span><span className="capitalize">{w.intensity}</span><strong>+{w.points}</strong></div>)}</section>}
      {page==='Squad Hub' && <section className="panel page-panel squad-hub"><div className="squad-banner"><div className="squad-symbol lime">I</div><div><div className="eyebrow">YOUR SQUAD</div><h2>{active.name}</h2><p>Five minds. One mission. Keep moving forward.</p></div><div className="squad-score"><b>{money(active.points)}</b><span>TOTAL POINTS</span></div></div><h3>Squad members</h3><div className="member-grid">{active.members.map((m:any)=><div className="member-card" key={m.id}><div className="avatar">{m.avatar}</div><b>{m.name}</b><span>{money(m.points)} points</span></div>)}</div><div className="goal-box"><Target/><div><b>Weekly team goal</b><span>{money(active.points)} / {money(active.goal)} points earned</span></div><div className="goal-track"><span style={{width:`${Math.min(100,active.points/active.goal*100)}%`}}/></div></div></section>}
      {page==='Achievements' && <section className="panel page-panel"><div className="panel-head"><div><div className="eyebrow">RECOGNITION THAT MATTERS</div><h3>Your achievement cabinet</h3></div><span className="badge-count">{unlocked.length} unlocked</span></div><div className="achievement-list">{data.badges.map(b=><div className={`achievement ${unlocked.some(x=>x.id===b.id)?'earned':''}`} key={b.id}><div className="achievement-icon">{b.icon}</div><div><b>{b.name}</b><span>{b.description}</span></div><div className="achievement-status">{unlocked.some(x=>x.id===b.id)?<><Check size={15}/> EARNED</>:'IN PROGRESS'}</div></div>)}</div></section>}
      <footer><span>FITFORGE <b>·</b> SWEATSQUAD SHOWDOWN</span><span>Progress over perfection. <Heart size={13}/></span></footer>
    </main>
    {modal && <div className="modal-backdrop" onClick={()=>setModal(false)}><form className="workout-modal" onSubmit={submitWorkout} onClick={e=>e.stopPropagation()}><button type="button" className="modal-close" onClick={()=>setModal(false)}>×</button><div className="eyebrow">ADD TO YOUR JOURNEY</div><h2>Log a workout</h2><p>Every activity adds momentum to your squad.</p><label>Activity type<select value={form.type} onChange={e=>setForm({...form,type:e.target.value})}><option>Running</option><option>Cycling</option><option>Push-ups</option><option>Gym</option></select></label><div className="form-two"><label>Duration (minutes)<input type="number" min="1" max="180" value={form.duration} onChange={e=>setForm({...form,duration:e.target.value})} required/></label><label>Distance (km)<input type="number" min="0" max="100" step=".1" value={form.distance} onChange={e=>setForm({...form,distance:e.target.value})}/></label></div><label>Perceived intensity<select value={form.intensity} onChange={e=>setForm({...form,intensity:e.target.value})}><option value="low">Low</option><option value="moderate">Moderate</option><option value="high">High</option></select></label><div className="points-preview"><Zap size={18}/><div><b>Points are calculated automatically</b><span>Duration × activity MET × intensity multiplier</span></div></div><button className="primary-btn submit-btn" disabled={loading}>{loading?'Saving…':'Save workout'} <ArrowUpRight size={17}/></button><small className="form-note">Demo profile: Aarav Mehta · Iron Legion</small></form></div>}
  </div>;
}
function Stat({icon,label,value,change,accent}:{icon:any,label:string,value:string,change:string,accent:string}) {
 return <div className="stat-card"><div className={`stat-icon ${accent}`}>{icon}</div><div className="stat-label">{label}</div><div className="stat-value">{value}</div><div className="stat-change">{change}</div></div>;
}
